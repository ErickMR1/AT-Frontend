import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-info-task',
  templateUrl: './info-task.component.html',
  styleUrls: ['./info-task.component.css']
})
export class InfoTaskComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
