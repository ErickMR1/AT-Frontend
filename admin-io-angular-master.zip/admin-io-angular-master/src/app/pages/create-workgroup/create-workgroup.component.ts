import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-workgroup',
  templateUrl: './create-workgroup.component.html',
  styleUrls: ['./create-workgroup.component.css']
})
export class CreateWorkgroupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
