export interface Users{
  idUser?: bigint;
  nameUser: string;
  email: string;
  password: string;
  descriptionUser: string;
  phone: number;
}

