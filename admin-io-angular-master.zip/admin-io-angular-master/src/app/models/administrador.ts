export interface Administrador{
  id_work:number;
  name_work:string;
  description_work:string;
  priority_work:string;
  process_work:string;
  startdate_work:Date;
  enddate_work:Date;
}
