import {Injectable} from "@angular/core";

@Injectable({
  providedIn: 'root'
})
export class api{
  static API_SERVER = "localhost:8080/adminapi/v1"
}
